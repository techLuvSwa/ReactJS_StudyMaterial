import React, {useState,useEffect} from 'react';
import axios from 'axios';
import validate from './validateInfo';
import useForm from './useForm';
import './Form.css';

const FormSignup = ({ submitForm }) => {
  const [userData, setUserData] = useState([]);
  
  const { handleChange, handleSubmit, values, errors } = useForm(
    submitForm,
    validate
  );

  

  const fetchStudy = async (e) =>{
    e.preventDefault();
    // const requestHeader = {
    //   method: "GET",
    //   headers: { 
    //     'Content-Type': 'application/json',
    //     // 'Authorization': 'TOKEN',
    //   },
    // }
    //   fetch("https://reqres.in/api/users?page=2", requestHeader)
    //     .then(res => console.log(res))
        
    //     .catch(err => console.log(err))
    const data = await axios.get("http://localhost:3000/api/study/");
    setUserData(data.data);
  }
  console.log(userData);


  const signUp = () =>{
    const data = {
      // name: "xyz",
      // email: "xyz@gmail.com",
      // contact: 9876543210,
      // password: "pass@123",
      // createdby: 1,
      name: values.name,
      email: values.email,
      contact: values.phoneno,
      password: values.password,
      createdby: 1
    }
    const requestHeader = {
      method: "POST",
      headers: { 'content-Type': 'application/json' },
      body: JSON.stringify(data),
    }

    {
      data && 
      fetch("http://localhost:3000/api/study/UserReg/", requestHeader)
        .then(res => {
          console.log(res);
        //  fetchStudy();
      })
        .catch(err => console.log(err))
    }
  }

 
  return (
    <div className='form-content-center'>
      <form onSubmit={handleSubmit} className='form' noValidate>
        <h1>Registration</h1>
        <div className='form-inputs'>
          <label className='form-label'>Name</label>
          <input
            className='form-input'
            type='text'
            name='name'
            placeholder='Enter your name'
            value={values.name}
            onChange={handleChange}
          />
          {errors.name && <p>{errors.name}</p>}
        </div>
        <div className='form-inputs'>
          <label className='form-label'>Email</label>
          <input
            className='form-input'
            type='email'
            name='email'
            placeholder='Enter your email'
            value={values.email}
            onChange={handleChange}
          />
          {errors.email && <p>{errors.email}</p>}
        </div>
        <div className='form-inputs'>
          <label className='form-label'>Phone No</label>
          <input
            className='form-input'
            type='number'
            name='phoneno'
            placeholder='Enter your phone no'
            value={values.phoneno}
            onChange={handleChange}
          />
          {errors.phoneno && <p>{errors.phoneno}</p>}
        </div>

        <div className='form-inputs'>
          <label className='form-label'>Password</label>
          <input
            className='form-input'
            type='password'
            name='password'
            placeholder='**************'
            value={values.password}
            onChange={handleChange}
          />
          {errors.password && <p>{errors.password}</p>}
        </div>
        
        <button className='form-input-btn' type='submit' onClick={signUp}>
          Sign up
        </button>
       
      </form>

      <button type='button' onClick={fetchStudy}>
          View
        </button>

    </div>
  );
};

export default FormSignup;
