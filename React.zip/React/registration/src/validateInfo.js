export default function validateInfo(values) {
    let errors = {};
  
    if (!values.name.trim()) {
      errors.name = 'Name required';
    }
    else if (!/^[A-Za-z]+/.test(values.name.trim())) {
       errors.name = 'Enter a valid Name';
    }
  
    if (!values.email) {
      errors.email = 'Email required';
    } else if (!/\S+@\S+\.\S+/.test(values.email)) {
      errors.email = 'Email address is invalid';
    }
   
    if (!values.phoneno) {
      errors.phoneno = 'Phone No is required';
    } else if (values.phoneno.length != 10) {
      errors.phoneno = 'Phone No needs to be 10 number';
    }

    if (!values.password) {
        errors.password = 'password is required';
      }
  
   
    return errors;
  }
  