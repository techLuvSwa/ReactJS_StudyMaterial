import React, {useState, useEffect} from 'react';
import axios from 'axios';
import validate from './validateInfo';
import useForm from './useForm';
import './Form.css';

const FormSignin = ({ submitForm }) => {

  const[userData, setUserData]= useState([]);

  const { handleChange, handleSubmit, values, errors } = useForm(
    submitForm,
    validate
  );

  const login = async (e) =>{
    e.preventDefault();
    // const requestHeader = {
    //   method: "GET",
    //   headers: { 
    //     'Content-Type': 'application/json',
    //     // 'Authorization': 'TOKEN',
    //   },
    // }
    //   fetch("https://reqres.in/api/users?page=2", requestHeader)
    //     .then(res => console.log(res))
        
    //     .catch(err => console.log(err))

    const data = axios.post('http://localhost:3000/api/study/UserLogin/', {
      
      email: values.username,    
      password: values.password
    })
    .then(function (response) {
      setUserData(response.data[0].UserId);
    });
 
  //  console.log(userData[0]);
    
  //  const data = await axios.get("http://localhost:3000/api/study/UserLogin/");
//    setUserData(data.data);
  }
 
    console.log(userData);
  
 
  //alert(userData[0].name+' Login Successfully');

  return (
    <div className='form-content-center'>
      <form onSubmit={handleSubmit} className='form' noValidate>
        <h1>Login</h1>
        <div className='form-inputs'>
          <label className='form-label'>Username</label>
          <input
            className='form-input'
            type='text'
            name='username'
            placeholder='Enter your username'
            value={values.username}
            onChange={handleChange}
          />
          {errors.username && <p>{errors.username}</p>}
        </div>
        
        <div className='form-inputs'>
          <label className='form-label'>Password</label>
          <input
            className='form-input'
            type='text'
            name='password'
            placeholder='Enter your password'
            value={values.password}
            onChange={handleChange}
          />
          {errors.password && <p>{errors.password}</p>}
        </div>

       
        
        <button className='form-input-btn' type='submit' onClick={login}>
          Login
        </button>
       
      </form>
    </div>
  );
};

export default FormSignin;
